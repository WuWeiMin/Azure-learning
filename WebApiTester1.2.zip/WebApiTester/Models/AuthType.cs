namespace WebApiTester.Models;

public enum AuthType
{
    None,
    Basic,
    BearerToken
}
