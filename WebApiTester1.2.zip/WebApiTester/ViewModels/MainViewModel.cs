using System.Collections.ObjectModel;
using CommunityToolkit.Mvvm.ComponentModel;
using CommunityToolkit.Mvvm.Input;
using WebApiTester.Models;
using WebApiTester.Services;

namespace WebApiTester.ViewModels;

public partial class MainViewModel : ObservableObject
{
    private readonly HttpRequestService _httpService = new();
    private readonly VariableResolver _resolver = new();

    // ---- 请求区 ----
    [ObservableProperty]
    private string method = "GET";

    public List<string> Methods { get; } = new() { "GET", "POST", "PUT", "PATCH", "DELETE" };

    [ObservableProperty]
    private string url = "https://jsonplaceholder.typicode.com/posts/1";

    [ObservableProperty]
    private string requestBody = string.Empty;

    [ObservableProperty]
    private string bodyContentType = "application/json";

    public ObservableCollection<HeaderItem> Headers { get; } = new()
    {
        new HeaderItem { Key = "Content-Type", Value = "application/json" }
    };

    // ---- 认证区 ----
    [ObservableProperty]
    private AuthType authType = AuthType.None;

    public List<AuthType> AuthTypes { get; } = new() { AuthType.None, AuthType.Basic, AuthType.BearerToken };

    [ObservableProperty]
    private string basicUsername = string.Empty;

    [ObservableProperty]
    private string basicPassword = string.Empty;

    [ObservableProperty]
    private string bearerToken = string.Empty;

    // ---- 环境变量区（简单版：baseUrl / token 等 key-value） ----
    public ObservableCollection<HeaderItem> Variables { get; } = new()
    {
        new HeaderItem { Key = "baseUrl", Value = "https://api.example.com" }
    };

    // ---- 响应区 ----
    [ObservableProperty]
    private string responseStatus = string.Empty;

    [ObservableProperty]
    private string responseTime = string.Empty;

    [ObservableProperty]
    private string responseHeaders = string.Empty;

    [ObservableProperty]
    private string responseBody = string.Empty;

    [ObservableProperty]
    private bool isSending;

    [ObservableProperty]
    private string statusBrush = "Black";

    [RelayCommand]
    private void AddHeader()
    {
        Headers.Add(new HeaderItem());
    }

    [RelayCommand]
    private void RemoveHeader(HeaderItem? item)
    {
        if (item != null) Headers.Remove(item);
    }

    [RelayCommand]
    private void AddVariable()
    {
        Variables.Add(new HeaderItem());
    }

    [RelayCommand]
    private void RemoveVariable(HeaderItem? item)
    {
        if (item != null) Variables.Remove(item);
    }

    [RelayCommand(CanExecute = nameof(CanSend))]
    private async Task SendAsync()
    {
        IsSending = true;
        ResponseBody = string.Empty;
        ResponseHeaders = string.Empty;
        ResponseStatus = "发送中...";

        try
        {
            var variableDict = Variables
                .Where(v => v.IsEnabled && !string.IsNullOrWhiteSpace(v.Key))
                .ToDictionary(v => v.Key, v => v.Value);

            var resolvedUrl = _resolver.Resolve(Url, variableDict);
            var resolvedBody = _resolver.Resolve(RequestBody, variableDict);

            var resolvedHeaders = Headers.Select(h => new HeaderItem
            {
                IsEnabled = h.IsEnabled,
                Key = _resolver.Resolve(h.Key, variableDict),
                Value = _resolver.Resolve(h.Value, variableDict)
            }).ToList();

            // 根据认证方式追加 Authorization header（会覆盖 Headers 里手动填的同名项）
            var authHeader = BuildAuthHeader(variableDict);
            if (authHeader != null)
            {
                resolvedHeaders.RemoveAll(h =>
                    string.Equals(h.Key, "Authorization", StringComparison.OrdinalIgnoreCase));
                resolvedHeaders.Add(authHeader);
            }

            var result = await _httpService.SendAsync(
                Method, resolvedUrl, resolvedHeaders, resolvedBody, BodyContentType);

            if (result.ErrorMessage != null)
            {
                ResponseStatus = "请求失败";
                ResponseBody = result.ErrorMessage;
                StatusBrush = "Red";
            }
            else
            {
                ResponseStatus = $"{result.StatusCode} {result.StatusText}";
                ResponseTime = $"{result.ElapsedMs} ms";
                ResponseHeaders = result.Headers;
                ResponseBody = result.Body;
                StatusBrush = result.IsSuccess ? "Green" : "OrangeRed";
            }
        }
        finally
        {
            IsSending = false;
        }
    }

    private HeaderItem? BuildAuthHeader(IDictionary<string, string> variableDict)
    {
        switch (AuthType)
        {
            case AuthType.Basic:
                var user = _resolver.Resolve(BasicUsername, variableDict);
                var pass = _resolver.Resolve(BasicPassword, variableDict);
                var raw = $"{user}:{pass}";
                var encoded = Convert.ToBase64String(System.Text.Encoding.UTF8.GetBytes(raw));
                return new HeaderItem { Key = "Authorization", Value = $"Basic {encoded}" };

            case AuthType.BearerToken:
                var token = _resolver.Resolve(BearerToken, variableDict);
                return new HeaderItem { Key = "Authorization", Value = $"Bearer {token}" };

            default:
                return null; // AuthType.None，不追加
        }
    }

    private bool CanSend() => !IsSending;

    partial void OnIsSendingChanged(bool value)
    {
        SendCommand.NotifyCanExecuteChanged();
    }
}
