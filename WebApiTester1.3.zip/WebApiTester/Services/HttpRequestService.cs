using System.Diagnostics;
using System.Net.Http;
using System.Text;
using WebApiTester.Models;

namespace WebApiTester.Services;

public class HttpRequestService
{
    // 复用一个静态 HttpClient，避免频繁创建导致端口耗尽
    private static readonly HttpClient _client = new HttpClient();

    public async Task<ResponseModel> SendAsync(
        string method,
        string url,
        IEnumerable<HeaderItem> headers,
        string? body,
        string bodyContentType,
        CancellationToken ct = default)
    {
        var result = new ResponseModel();
        var sw = Stopwatch.StartNew();

        try
        {
            using var request = new HttpRequestMessage(new HttpMethod(method), url);

            // 添加启用的 Headers
            foreach (var h in headers)
            {
                if (h.IsEnabled && !string.IsNullOrWhiteSpace(h.Key))
                {
                    request.Headers.TryAddWithoutValidation(h.Key, h.Value);
                }
            }

            // 只有支持 Body 的方法才附加内容
            if (!string.IsNullOrEmpty(body) &&
                method is "POST" or "PUT" or "PATCH" or "DELETE")
            {
                request.Content = new StringContent(body, Encoding.UTF8, bodyContentType);
            }

            using var response = await _client.SendAsync(request, ct);
            sw.Stop();

            var responseBody = await response.Content.ReadAsStringAsync(ct);

            result.StatusCode = (int)response.StatusCode;
            result.StatusText = response.StatusCode.ToString();
            result.ElapsedMs = sw.ElapsedMilliseconds;
            result.IsSuccess = response.IsSuccessStatusCode;
            result.Body = TryFormatJson(responseBody);

            var headerLines = new StringBuilder();
            foreach (var h in response.Headers)
                headerLines.AppendLine($"{h.Key}: {string.Join(", ", h.Value)}");
            foreach (var h in response.Content.Headers)
                headerLines.AppendLine($"{h.Key}: {string.Join(", ", h.Value)}");
            result.Headers = headerLines.ToString();
        }
        catch (Exception ex)
        {
            sw.Stop();
            result.IsSuccess = false;
            result.ElapsedMs = sw.ElapsedMilliseconds;
            result.ErrorMessage = ex.Message;
        }

        return result;
    }

    // 尝试把返回的 JSON 字符串格式化，方便阅读；失败则原样返回
    private static string TryFormatJson(string raw)
    {
        if (string.IsNullOrWhiteSpace(raw)) return raw;
        try
        {
            using var doc = System.Text.Json.JsonDocument.Parse(raw);
            return System.Text.Json.JsonSerializer.Serialize(
                doc,
                new System.Text.Json.JsonSerializerOptions { WriteIndented = true });
        }
        catch
        {
            return raw; // 不是合法 JSON，原样返回（比如纯文本或 HTML）
        }
    }
}
