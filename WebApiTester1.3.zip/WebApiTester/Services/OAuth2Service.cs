using System.Diagnostics;
using System.Net;
using System.Net.Http;
using System.Text.Json;
using WebApiTester.Models;

namespace WebApiTester.Services;

public class OAuth2Service
{
    private static readonly HttpClient _client = new HttpClient();

    // ---- Client Credentials：服务端对服务端，没有浏览器交互 ----
    public async Task<OAuth2TokenResult> GetClientCredentialsTokenAsync(
        string tokenUrl, string clientId, string clientSecret, string scope, CancellationToken ct = default)
    {
        try
        {
            var form = new Dictionary<string, string>
            {
                ["grant_type"] = "client_credentials",
                ["client_id"] = clientId,
                ["client_secret"] = clientSecret
            };
            if (!string.IsNullOrWhiteSpace(scope)) form["scope"] = scope;

            using var content = new FormUrlEncodedContent(form);
            using var response = await _client.PostAsync(tokenUrl, content, ct);
            var raw = await response.Content.ReadAsStringAsync(ct);

            if (!response.IsSuccessStatusCode)
            {
                return new OAuth2TokenResult
                {
                    IsSuccess = false,
                    ErrorMessage = $"{(int)response.StatusCode} {response.StatusCode}: {raw}"
                };
            }

            return ParseTokenResponse(raw);
        }
        catch (Exception ex)
        {
            return new OAuth2TokenResult { IsSuccess = false, ErrorMessage = ex.Message };
        }
    }

    // ---- Authorization Code：打开系统浏览器登录，本地监听回调拿 code，再换 token ----
    public async Task<OAuth2TokenResult> GetAuthorizationCodeTokenAsync(
        string authorizationUrl, string tokenUrl, string clientId, string clientSecret,
        string redirectUri, string scope, CancellationToken ct = default)
    {
        HttpListener? listener = null;
        try
        {
            // redirectUri 必须是 http://localhost:PORT/xxx/ 形式（末尾带斜杠）才能被 HttpListener 监听
            var prefix = redirectUri.EndsWith("/") ? redirectUri : redirectUri + "/";

            listener = new HttpListener();
            listener.Prefixes.Add(prefix);
            listener.Start();

            var state = Guid.NewGuid().ToString("N");
            var authUrlFull = $"{authorizationUrl}?response_type=code&client_id={Uri.EscapeDataString(clientId)}" +
                               $"&redirect_uri={Uri.EscapeDataString(redirectUri)}&state={state}";
            if (!string.IsNullOrWhiteSpace(scope))
                authUrlFull += $"&scope={Uri.EscapeDataString(scope)}";

            // 用系统默认浏览器打开授权页面
            Process.Start(new ProcessStartInfo(authUrlFull) { UseShellExecute = true });

            // 等待浏览器回调，最多等 2 分钟
            var getContextTask = listener.GetContextAsync();
            var timeoutTask = Task.Delay(TimeSpan.FromMinutes(2), ct);
            var completed = await Task.WhenAny(getContextTask, timeoutTask);

            if (completed == timeoutTask)
            {
                return new OAuth2TokenResult { IsSuccess = false, ErrorMessage = "等待授权超时（2 分钟），请重试" };
            }

            var context = getContextTask.Result;
            var query = context.Request.QueryString;
            var code = query["code"];
            var returnedState = query["state"];
            var error = query["error"];

            // 给浏览器一个友好的回显页面
            var responseHtml = error == null
                ? "<html><body><h3>授权成功，可以关闭此窗口返回 Web API Tester。</h3></body></html>"
                : $"<html><body><h3>授权失败：{error}</h3></body></html>";
            var buffer = System.Text.Encoding.UTF8.GetBytes(responseHtml);
            context.Response.ContentLength64 = buffer.Length;
            await context.Response.OutputStream.WriteAsync(buffer, ct);
            context.Response.OutputStream.Close();

            if (error != null)
                return new OAuth2TokenResult { IsSuccess = false, ErrorMessage = $"授权服务器返回错误: {error}" };

            if (string.IsNullOrEmpty(code))
                return new OAuth2TokenResult { IsSuccess = false, ErrorMessage = "回调中没有拿到 code 参数" };

            if (returnedState != state)
                return new OAuth2TokenResult { IsSuccess = false, ErrorMessage = "state 校验失败，可能存在安全风险，已终止" };

            // 用 code 换 token
            var form = new Dictionary<string, string>
            {
                ["grant_type"] = "authorization_code",
                ["code"] = code,
                ["redirect_uri"] = redirectUri,
                ["client_id"] = clientId
            };
            if (!string.IsNullOrWhiteSpace(clientSecret)) form["client_secret"] = clientSecret;

            using var content = new FormUrlEncodedContent(form);
            using var tokenResponse = await _client.PostAsync(tokenUrl, content, ct);
            var raw = await tokenResponse.Content.ReadAsStringAsync(ct);

            if (!tokenResponse.IsSuccessStatusCode)
            {
                return new OAuth2TokenResult
                {
                    IsSuccess = false,
                    ErrorMessage = $"{(int)tokenResponse.StatusCode} {tokenResponse.StatusCode}: {raw}"
                };
            }

            return ParseTokenResponse(raw);
        }
        catch (Exception ex)
        {
            return new OAuth2TokenResult { IsSuccess = false, ErrorMessage = ex.Message };
        }
        finally
        {
            listener?.Stop();
            listener?.Close();
        }
    }

    private static OAuth2TokenResult ParseTokenResponse(string raw)
    {
        using var doc = JsonDocument.Parse(raw);
        var root = doc.RootElement;

        var result = new OAuth2TokenResult { IsSuccess = true };

        if (root.TryGetProperty("access_token", out var at)) result.AccessToken = at.GetString();
        if (root.TryGetProperty("token_type", out var tt)) result.TokenType = tt.GetString();
        if (root.TryGetProperty("refresh_token", out var rt)) result.RefreshToken = rt.GetString();
        if (root.TryGetProperty("expires_in", out var ei))
        {
            result.ExpiresIn = ei.ValueKind == JsonValueKind.Number
                ? ei.GetInt32()
                : int.TryParse(ei.GetString(), out var parsed) ? parsed : null;
        }

        if (string.IsNullOrEmpty(result.AccessToken))
        {
            result.IsSuccess = false;
            result.ErrorMessage = "响应中没有 access_token 字段，原始返回: " + raw;
        }

        return result;
    }
}
