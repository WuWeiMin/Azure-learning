namespace WebApiTester.Models;

public class ResponseModel
{
    public int StatusCode { get; set; }
    public string StatusText { get; set; } = string.Empty;
    public long ElapsedMs { get; set; }
    public string Headers { get; set; } = string.Empty;
    public string Body { get; set; } = string.Empty;
    public bool IsSuccess { get; set; }
    public string? ErrorMessage { get; set; }
}
