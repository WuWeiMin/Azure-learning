namespace WebApiTester.Models;

public class OAuth2TokenResult
{
    public bool IsSuccess { get; set; }
    public string? AccessToken { get; set; }
    public string? TokenType { get; set; }
    public int? ExpiresIn { get; set; }
    public string? RefreshToken { get; set; }
    public DateTime ObtainedAt { get; set; } = DateTime.Now;
    public string? ErrorMessage { get; set; }

    public DateTime? ExpiresAt => ExpiresIn.HasValue ? ObtainedAt.AddSeconds(ExpiresIn.Value) : null;

    public bool IsExpired => ExpiresAt.HasValue && DateTime.Now >= ExpiresAt.Value;
}
