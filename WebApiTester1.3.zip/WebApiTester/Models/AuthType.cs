namespace WebApiTester.Models;

public enum AuthType
{
    None,
    Basic,
    BearerToken,
    OAuth2ClientCredentials,
    OAuth2AuthorizationCode
}
