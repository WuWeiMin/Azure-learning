using CommunityToolkit.Mvvm.ComponentModel;

namespace WebApiTester.Models;

// 表示一行 Header 或 Query Param，可以勾选是否启用
public partial class HeaderItem : ObservableObject
{
    [ObservableProperty]
    private bool isEnabled = true;

    [ObservableProperty]
    private string key = string.Empty;

    [ObservableProperty]
    private string value = string.Empty;
}
