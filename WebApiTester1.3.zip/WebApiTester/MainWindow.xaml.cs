using System.Windows;
using System.Windows.Controls;
using WebApiTester.ViewModels;

namespace WebApiTester;

public partial class MainWindow : Window
{
    public MainWindow()
    {
        InitializeComponent();
    }

    // PasswordBox 出于安全考虑不支持直接数据绑定 Password 属性，这里手动同步到 ViewModel
    private void BasicPasswordBox_PasswordChanged(object sender, RoutedEventArgs e)
    {
        if (DataContext is MainViewModel vm && sender is PasswordBox pb)
        {
            vm.BasicPassword = pb.Password;
        }
    }
}
