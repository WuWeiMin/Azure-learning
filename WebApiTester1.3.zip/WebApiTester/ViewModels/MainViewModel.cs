using System.Collections.ObjectModel;
using CommunityToolkit.Mvvm.ComponentModel;
using CommunityToolkit.Mvvm.Input;
using WebApiTester.Models;
using WebApiTester.Services;

namespace WebApiTester.ViewModels;

public partial class MainViewModel : ObservableObject
{
    private readonly HttpRequestService _httpService = new();
    private readonly VariableResolver _resolver = new();
    private readonly OAuth2Service _oauth2Service = new();

    // ---- 请求区 ----
    [ObservableProperty]
    private string method = "GET";

    public List<string> Methods { get; } = new() { "GET", "POST", "PUT", "PATCH", "DELETE" };

    [ObservableProperty]
    private string url = "https://jsonplaceholder.typicode.com/posts/1";

    [ObservableProperty]
    private string requestBody = string.Empty;

    [ObservableProperty]
    private string bodyContentType = "application/json";

    public ObservableCollection<HeaderItem> Headers { get; } = new()
    {
        new HeaderItem { Key = "Content-Type", Value = "application/json" }
    };

    // ---- 认证区 ----
    [ObservableProperty]
    private AuthType authType = AuthType.None;

    public List<AuthType> AuthTypes { get; } = new()
    {
        AuthType.None, AuthType.Basic, AuthType.BearerToken,
        AuthType.OAuth2ClientCredentials, AuthType.OAuth2AuthorizationCode
    };

    [ObservableProperty]
    private string basicUsername = string.Empty;

    [ObservableProperty]
    private string basicPassword = string.Empty;

    [ObservableProperty]
    private string bearerToken = string.Empty;

    // ---- OAuth2 通用字段 ----
    [ObservableProperty]
    private string oauth2TokenUrl = string.Empty;

    [ObservableProperty]
    private string oauth2ClientId = string.Empty;

    [ObservableProperty]
    private string oauth2ClientSecret = string.Empty;

    [ObservableProperty]
    private string oauth2Scope = string.Empty;

    // Authorization Code 专用
    [ObservableProperty]
    private string oauth2AuthorizationUrl = string.Empty;

    [ObservableProperty]
    private string oauth2RedirectUri = "http://localhost:14520/callback/";

    // 换回来的 token 状态展示
    [ObservableProperty]
    private string oauth2AccessToken = string.Empty;

    [ObservableProperty]
    private string oauth2TokenStatus = "尚未获取 Token";

    [ObservableProperty]
    private bool isFetchingToken;

    private OAuth2TokenResult? _lastTokenResult;

    // ---- 环境变量区（简单版：baseUrl / token 等 key-value） ----
    public ObservableCollection<HeaderItem> Variables { get; } = new()
    {
        new HeaderItem { Key = "baseUrl", Value = "https://api.example.com" }
    };

    // ---- 响应区 ----
    [ObservableProperty]
    private string responseStatus = string.Empty;

    [ObservableProperty]
    private string responseTime = string.Empty;

    [ObservableProperty]
    private string responseHeaders = string.Empty;

    [ObservableProperty]
    private string responseBody = string.Empty;

    [ObservableProperty]
    private bool isSending;

    [ObservableProperty]
    private string statusBrush = "Black";

    [RelayCommand]
    private void AddHeader()
    {
        Headers.Add(new HeaderItem());
    }

    [RelayCommand]
    private void RemoveHeader(HeaderItem? item)
    {
        if (item != null) Headers.Remove(item);
    }

    [RelayCommand]
    private void AddVariable()
    {
        Variables.Add(new HeaderItem());
    }

    [RelayCommand]
    private void RemoveVariable(HeaderItem? item)
    {
        if (item != null) Variables.Remove(item);
    }

    [RelayCommand(CanExecute = nameof(CanSend))]
    private async Task SendAsync()
    {
        IsSending = true;
        ResponseBody = string.Empty;
        ResponseHeaders = string.Empty;
        ResponseStatus = "发送中...";

        try
        {
            var variableDict = Variables
                .Where(v => v.IsEnabled && !string.IsNullOrWhiteSpace(v.Key))
                .ToDictionary(v => v.Key, v => v.Value);

            var resolvedUrl = _resolver.Resolve(Url, variableDict);
            var resolvedBody = _resolver.Resolve(RequestBody, variableDict);

            // OAuth2 Client Credentials：token 缺失或过期时自动去换一个，不需要用户手动点按钮
            if (AuthType == AuthType.OAuth2ClientCredentials &&
                (string.IsNullOrEmpty(Oauth2AccessToken) || (_lastTokenResult?.IsExpired ?? false)))
            {
                var tokenResult = await _oauth2Service.GetClientCredentialsTokenAsync(
                    _resolver.Resolve(Oauth2TokenUrl, variableDict),
                    _resolver.Resolve(Oauth2ClientId, variableDict),
                    _resolver.Resolve(Oauth2ClientSecret, variableDict),
                    _resolver.Resolve(Oauth2Scope, variableDict));
                ApplyTokenResult(tokenResult);
            }

            // OAuth2 Authorization Code 需要浏览器登录，不在 Send 时自动触发，提示用户先点「获取 Token」
            if (AuthType == AuthType.OAuth2AuthorizationCode && string.IsNullOrEmpty(Oauth2AccessToken))
            {
                ResponseStatus = "请求失败";
                ResponseBody = "还没有获取 OAuth2 Token，请先在 Auth Tab 点击「获取 Token」完成登录授权";
                StatusBrush = "Red";
                return;
            }

            if (AuthType == AuthType.OAuth2ClientCredentials && string.IsNullOrEmpty(Oauth2AccessToken))
            {
                ResponseStatus = "请求失败";
                ResponseBody = $"获取 OAuth2 Token 失败: {Oauth2TokenStatus}";
                StatusBrush = "Red";
                return;
            }

            var resolvedHeaders = Headers.Select(h => new HeaderItem
            {
                IsEnabled = h.IsEnabled,
                Key = _resolver.Resolve(h.Key, variableDict),
                Value = _resolver.Resolve(h.Value, variableDict)
            }).ToList();

            // 根据认证方式追加 Authorization header（会覆盖 Headers 里手动填的同名项）
            var authHeader = BuildAuthHeader(variableDict);
            if (authHeader != null)
            {
                resolvedHeaders.RemoveAll(h =>
                    string.Equals(h.Key, "Authorization", StringComparison.OrdinalIgnoreCase));
                resolvedHeaders.Add(authHeader);
            }

            var result = await _httpService.SendAsync(
                Method, resolvedUrl, resolvedHeaders, resolvedBody, BodyContentType);

            if (result.ErrorMessage != null)
            {
                ResponseStatus = "请求失败";
                ResponseBody = result.ErrorMessage;
                StatusBrush = "Red";
            }
            else
            {
                ResponseStatus = $"{result.StatusCode} {result.StatusText}";
                ResponseTime = $"{result.ElapsedMs} ms";
                ResponseHeaders = result.Headers;
                ResponseBody = result.Body;
                StatusBrush = result.IsSuccess ? "Green" : "OrangeRed";
            }
        }
        finally
        {
            IsSending = false;
        }
    }

    [RelayCommand]
    private async Task GetTokenAsync()
    {
        IsFetchingToken = true;
        Oauth2TokenStatus = "获取中...";

        try
        {
            var variableDict = Variables
                .Where(v => v.IsEnabled && !string.IsNullOrWhiteSpace(v.Key))
                .ToDictionary(v => v.Key, v => v.Value);

            OAuth2TokenResult result;

            if (AuthType == AuthType.OAuth2ClientCredentials)
            {
                result = await _oauth2Service.GetClientCredentialsTokenAsync(
                    _resolver.Resolve(Oauth2TokenUrl, variableDict),
                    _resolver.Resolve(Oauth2ClientId, variableDict),
                    _resolver.Resolve(Oauth2ClientSecret, variableDict),
                    _resolver.Resolve(Oauth2Scope, variableDict));
            }
            else if (AuthType == AuthType.OAuth2AuthorizationCode)
            {
                result = await _oauth2Service.GetAuthorizationCodeTokenAsync(
                    _resolver.Resolve(Oauth2AuthorizationUrl, variableDict),
                    _resolver.Resolve(Oauth2TokenUrl, variableDict),
                    _resolver.Resolve(Oauth2ClientId, variableDict),
                    _resolver.Resolve(Oauth2ClientSecret, variableDict),
                    _resolver.Resolve(Oauth2RedirectUri, variableDict),
                    _resolver.Resolve(Oauth2Scope, variableDict));
            }
            else
            {
                return; // 不是 OAuth2 类型，不处理
            }

            ApplyTokenResult(result);
        }
        finally
        {
            IsFetchingToken = false;
        }
    }

    private void ApplyTokenResult(OAuth2TokenResult result)
    {
        _lastTokenResult = result;

        if (!result.IsSuccess)
        {
            Oauth2AccessToken = string.Empty;
            Oauth2TokenStatus = $"获取失败: {result.ErrorMessage}";
            return;
        }

        Oauth2AccessToken = result.AccessToken ?? string.Empty;
        Oauth2TokenStatus = result.ExpiresAt.HasValue
            ? $"已获取，有效期至 {result.ExpiresAt.Value:HH:mm:ss}"
            : "已获取（未返回过期时间）";
    }

    private HeaderItem? BuildAuthHeader(IDictionary<string, string> variableDict)
    {
        switch (AuthType)
        {
            case AuthType.Basic:
                var user = _resolver.Resolve(BasicUsername, variableDict);
                var pass = _resolver.Resolve(BasicPassword, variableDict);
                var raw = $"{user}:{pass}";
                var encoded = Convert.ToBase64String(System.Text.Encoding.UTF8.GetBytes(raw));
                return new HeaderItem { Key = "Authorization", Value = $"Basic {encoded}" };

            case AuthType.BearerToken:
                var token = _resolver.Resolve(BearerToken, variableDict);
                return new HeaderItem { Key = "Authorization", Value = $"Bearer {token}" };

            case AuthType.OAuth2ClientCredentials:
            case AuthType.OAuth2AuthorizationCode:
                if (string.IsNullOrEmpty(Oauth2AccessToken)) return null;
                var tokenType = _lastTokenResult?.TokenType;
                var scheme = string.IsNullOrWhiteSpace(tokenType) ? "Bearer" : tokenType;
                return new HeaderItem { Key = "Authorization", Value = $"{scheme} {Oauth2AccessToken}" };

            default:
                return null; // AuthType.None，不追加
        }
    }

    private bool CanSend() => !IsSending;

    partial void OnIsSendingChanged(bool value)
    {
        SendCommand.NotifyCanExecuteChanged();
    }
}
